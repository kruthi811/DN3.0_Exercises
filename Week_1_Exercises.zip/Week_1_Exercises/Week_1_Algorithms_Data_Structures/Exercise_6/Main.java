public class Main {
    public static void main(String[] args) {
        LibraryManagement library = new LibraryManagement(2);

        Book b1 = new Book("B001", "Java Programming", "XYZ");
        Book b2 = new Book("B002", "Python Web Frameworks", "ABC");
        Book b3 = new Book("B003", "Data Structures", "PQR");

        library.addBook(b1);
        library.addBook(b2);
        library.addBook(b3);

        System.out.println("All Books:");
        for (Book book : library.books) {
            if (book != null) {
                System.out.println(book);
            }
        }

        System.out.println("\nLinear Search for 'Python Web Frameworks':");
        Book foundBook = library.linearSearchByTitle("Python Web Frameworks");
        System.out.println(foundBook != null ? foundBook : "Book not found");

        System.out.println("\nBinary Search for 'Python Web Frameworks':");
        library.sortBooksByTitle();
        foundBook = library.binarySearchByTitle("Python Web Frameworks");
        System.out.println(foundBook != null ? foundBook : "Book not found");
    }
}
