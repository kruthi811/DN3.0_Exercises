public class Main {
    public static void main(String[] args) {
        Product[] products = {
            new Product("P001", "Laptop", "Electronics"),
            new Product("P002", "Smartphone", "Electronics"),
            new Product("P003", "Tablet", "Electronics")
        };

        
        Product result = SearchAlgorithms.linearSearch(products, "Smartphone");
        System.out.println(result != null ? "Product found: " + result.getProductName() : "Product not found");

        
        SearchAlgorithms.sortProducts(products);

        
        result = SearchAlgorithms.binarySearch(products, "Tablet");
        System.out.println(result != null ? "Product found: " + result.getProductName() : "Product not found");
    }
}
