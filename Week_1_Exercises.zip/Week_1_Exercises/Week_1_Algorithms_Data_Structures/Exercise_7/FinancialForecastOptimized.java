import java.util.HashMap;
import java.util.Map;

public class FinancialForecastOptimized {

    private Map<Integer, Double> memo = new HashMap<>();

    public double forecastValue(double initialValue, double growthRate, int years) {
        
        if (memo.containsKey(years)) {
            return memo.get(years);
        }

        
        if (years == 0) {
            return initialValue;
        }

        
        double futureValue = forecastValue(initialValue * (1 + growthRate), growthRate, years - 1);
        memo.put(years, futureValue);
        return futureValue;
    }

    public static void main(String[] args) {
        FinancialForecastOptimized forecast = new FinancialForecastOptimized();

        double initialValue = 1000.0; 
        double growthRate = 0.05; 
        int years = 10; 

        double futureValue = forecast.forecastValue(initialValue, growthRate, years);
        System.out.println("Future Value: " + futureValue);
    }
}
