import java.util.ArrayList;
import java.util.HashMap;

public class InventoryManager {
    private ArrayList<Product> inventory;
    private HashMap<String, Product> inventoryMap;

    public InventoryManager() {
        inventory = new ArrayList<>();
        inventoryMap = new HashMap<>();
    }

    public void addProduct(Product product) {
        inventory.add(product);
        inventoryMap.put(product.getProductId(), product);
    }

    public void updateProduct(Product product) {
        String productId = product.getProductId();
        if (inventoryMap.containsKey(productId)) {
            
            for (int i = 0; i < inventory.size(); i++) {
                if (inventory.get(i).getProductId().equals(productId)) {
                    inventory.set(i, product);
                    break;
                }
            }
           
            inventoryMap.put(productId, product);
        }
    }

    public void deleteProduct(String productId) {
        if (inventoryMap.containsKey(productId)) {
            
            inventory.removeIf(product -> product.getProductId().equals(productId));
           
            inventoryMap.remove(productId);
        }
    }

    public Product getProduct(String productId) {
        return inventoryMap.get(productId);
    }

    public static void main(String[] args) {
        InventoryManager manager = new InventoryManager();

        
        manager.addProduct(new Product("P001", "Laptop", 10, 999.99));
        manager.addProduct(new Product("P002", "Smartphone", 20, 8899.99));
        manager.addProduct(new Product("P003", "Tablet", 15, 299.99));

        
        Product product = manager.getProduct("P002");
        if (product != null) {
            System.out.println("Product ID: " + product.getProductId());
            System.out.println("Product Name: " + product.getProductName());
            System.out.println("Quantity: " + product.getQuantity());
            System.out.println("Price: " + product.getPrice());
        } else {
            System.out.println("Product not found!");
        }

       
        manager.updateProduct(new Product("P002", "Smartphone", 25, 8999.99));

      
        manager.deleteProduct("P003");
    }
}
