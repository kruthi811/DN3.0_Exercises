public class Main {
    public static void main(String[] args) {
        Order[] orders = {
            new Order("O001", "Kruthi", 250.0),
            new Order("O002", "Venkatesh", 300.0),
            new Order("O003", "Chitra", 200.0)
        };

        
        System.out.println("Bubble Sort:");
        SortingAlgorithms.bubbleSort(orders);
        for (Order order : orders) {
            System.out.println(order);
        }

        
        orders = new Order[]{
            new Order("O001", "Kruthi", 250.0),
            new Order("O002", "Venkatesh", 300.0),
            new Order("O003", "Chitra", 200.0)
        };

        
        System.out.println("Quick Sort:");
        SortingAlgorithms.quickSort(orders, 0, orders.length - 1);
        for (Order order : orders) {
            System.out.println(order);
        }
    }
}
