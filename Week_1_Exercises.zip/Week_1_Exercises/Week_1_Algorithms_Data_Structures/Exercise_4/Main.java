public class Main {
    public static void main(String[] args) {
        EmployeeManagement management = new EmployeeManagement(2);

        Employee e1 = new Employee("E001", "Kruthi", "Manager", 80000);
        Employee e2 = new Employee("E002", "Venkatesh", "Developer", 70000);
        Employee e3 = new Employee("E003", "Chitra", "Designer", 90000);

        management.addEmployee(e1);
        management.addEmployee(e2);
        management.addEmployee(e3);

        System.out.println("All Employees:");
        management.traverseEmployees();

        System.out.println("\nSearch Employee with ID E002:");
        Employee employee = management.searchEmployee("E002");
        System.out.println(employee != null ? employee : "Employee not found");

        System.out.println("\nDelete Employee with ID E002:");
        boolean deleted = management.deleteEmployee("E002");
        System.out.println(deleted ? "Employee deleted" : "Employee not found");

        System.out.println("\nAll Employees after deletion:");
        management.traverseEmployees();
    }
}
