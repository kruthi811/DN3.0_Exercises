public class Main {
    public static void main(String[] args) {
        TaskLinkedList taskList = new TaskLinkedList();

        Task t1 = new Task("T001", "Design database", "Pending");
        Task t2 = new Task("T002", "Implement API", "In Progress");
        Task t3 = new Task("T003", "Test application", "Pending");

        taskList.addTask(t1);
        taskList.addTask(t2);
        taskList.addTask(t3);

        System.out.println("All Tasks:");
        taskList.traverseTasks();

        System.out.println("\nSearch Task with ID T002:");
        Task task = taskList.searchTask("T002");
        System.out.println(task != null ? task : "Task not found");

        System.out.println("\nDelete Task with ID T002:");
        boolean deleted = taskList.deleteTask("T002");
        System.out.println(deleted ? "Task deleted" : "Task not found");

        System.out.println("\nAll Tasks after deletion:");
        taskList.traverseTasks();
    }
}
