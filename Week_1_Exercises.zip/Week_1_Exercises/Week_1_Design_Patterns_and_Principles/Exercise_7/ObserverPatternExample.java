public class ObserverPatternExample {
    public static void main(String[] args) {
        StockMarket stockMarket = new StockMarket("ABCCorp", 150.00);

        Observer mobileApp = new MobileApp();
        Observer webApp = new WebApp();

        stockMarket.registerObserver(mobileApp);
        stockMarket.registerObserver(webApp);

        System.out.println("Updating stock price...");
        stockMarket.setPrice(188.00);

        System.out.println("Deregistering MobileApp and updating stock price...");
        stockMarket.deregisterObserver(mobileApp);
        stockMarket.setPrice(187.00);
    }
}
