public class LoggerTest {
    public static void main(String[] args) {
        Logger logger_1 = Logger.getInstance();
        Logger logger_2 = Logger.getInstance();

        if (logger_1 == logger_2) {
            System.out.println("Both Logger 1 and Logger 2 are the same instance");
        } else {
            System.out.println("Both are different instances");
        }

        logger_1.log("Logger 1 instance message");
        logger_2.log("Logger 2 instance message");
    }
}
