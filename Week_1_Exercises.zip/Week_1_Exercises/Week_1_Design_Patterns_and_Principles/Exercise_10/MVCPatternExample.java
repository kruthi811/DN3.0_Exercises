public class MVCPatternExample {
    public static void main(String[] args) {
        
        Student student = new Student("Kruthi V", "12345", "A");

        
        StudentView view = new StudentView();

        
        StudentController controller = new StudentController(student, view);

       
        controller.updateView();

        
        controller.setStudentName("Kruthi Venkatesh");
        controller.setStudentGrade("S");

        
        controller.updateView();
    }
}
