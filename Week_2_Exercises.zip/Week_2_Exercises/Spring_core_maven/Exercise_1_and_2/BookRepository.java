package com.library.repository;

public class BookRepository {
    // Data access methods
}
