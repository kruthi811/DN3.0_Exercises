DECLARE
    CURSOR transactions_cur IS
        SELECT c.CustomerID, c.Name, t.TransactionID, t.TransactionDate, t.Amount, t.TransactionType
        FROM Customers c
        JOIN Accounts a ON c.CustomerID = a.CustomerID
        JOIN Transactions t ON a.AccountID = t.AccountID
        WHERE t.TransactionDate >= TRUNC(SYSDATE, 'MM') 
          AND t.TransactionDate < ADD_MONTHS(TRUNC(SYSDATE, 'MM'), 1)
        ORDER BY c.CustomerID, t.TransactionDate;

    v_customer_id Customers.CustomerID%TYPE;
    v_customer_name Customers.Name%TYPE;
    v_transaction_id Transactions.TransactionID%TYPE;
    v_transaction_date Transactions.TransactionDate%TYPE;
    v_amount Transactions.Amount%TYPE;
    v_transaction_type Transactions.TransactionType%TYPE;
BEGIN
    OPEN transactions_cur;
    LOOP
        FETCH transactions_cur INTO v_customer_id, v_customer_name, v_transaction_id, v_transaction_date, v_amount, v_transaction_type;
        EXIT WHEN transactions_cur%NOTFOUND;

        DBMS_OUTPUT.PUT_LINE('Customer ID: ' || v_customer_id || ', Name: ' || v_customer_name);
        DBMS_OUTPUT.PUT_LINE('Transaction ID: ' || v_transaction_id || ', Date: ' || v_transaction_date);
        DBMS_OUTPUT.PUT_LINE('Amount: ' || v_amount || ', Type: ' || v_transaction_type);
        DBMS_OUTPUT.PUT_LINE('-----------------------------------------');
    END LOOP;
    CLOSE transactions_cur;
END;

DECLARE
    CURSOR accounts_cur IS
        SELECT AccountID, Balance
        FROM Accounts
        FOR UPDATE;

    v_account_id Accounts.AccountID%TYPE;
    v_balance Accounts.Balance%TYPE;
    v_annual_fee CONSTANT NUMBER := 50; -- Annual fee amount
BEGIN
    OPEN accounts_cur;
    LOOP
        FETCH accounts_cur INTO v_account_id, v_balance;
        EXIT WHEN accounts_cur%NOTFOUND;

        UPDATE Accounts
        SET Balance = Balance - v_annual_fee,
            LastModified = SYSDATE
        WHERE AccountID = v_account_id;

        DBMS_OUTPUT.PUT_LINE('Annual fee of ' || v_annual_fee || ' applied to Account ID: ' || v_account_id);
    END LOOP;
    CLOSE accounts_cur;
    COMMIT;
END;

DECLARE
    CURSOR loans_cur IS
        SELECT LoanID, InterestRate
        FROM Loans
        FOR UPDATE;

    v_loan_id Loans.LoanID%TYPE;
    v_interest_rate Loans.InterestRate%TYPE;
    v_new_interest_rate Loans.InterestRate%TYPE;
BEGIN
    OPEN loans_cur;
    LOOP
        FETCH loans_cur INTO v_loan_id, v_interest_rate;
        EXIT WHEN loans_cur%NOTFOUND;

        -- Example new policy: Increase interest rate by 0.5%
        v_new_interest_rate := v_interest_rate + 0.5;

        UPDATE Loans
        SET InterestRate = v_new_interest_rate,
            LastModified = SYSDATE
        WHERE LoanID = v_loan_id;

        DBMS_OUTPUT.PUT_LINE('Updated Loan ID: ' || v_loan_id || ' with new interest rate: ' || v_new_interest_rate);
    END LOOP;
    CLOSE loans_cur;
    COMMIT;
END;


BEGIN
    -- Generate monthly statements
    <your block code for GenerateMonthlyStatements>;
END;
/

BEGIN
    -- Apply annual fee
    <your block code for ApplyAnnualFee>;
END;
/

BEGIN
    -- Update loan interest rates
    <your block code for UpdateLoanInterestRates>;
END;
/
