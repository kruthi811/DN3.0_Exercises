DECLARE
    v_customer_age NUMBER;
    v_customer_id  Customers.CustomerID%TYPE;
    v_dob          Customers.DOB%TYPE;
    CURSOR customer_cur IS
        SELECT CustomerID, DOB FROM Customers;
BEGIN
    FOR customer_rec IN customer_cur LOOP
        v_customer_id := customer_rec.CustomerID;
        v_dob := customer_rec.DOB;
        v_customer_age := FLOOR(MONTHS_BETWEEN(SYSDATE, v_dob) / 12);
        
        IF v_customer_age > 60 THEN
            UPDATE Loans
            SET InterestRate = InterestRate - 1
            WHERE CustomerID = v_customer_id;
        END IF;
    END LOOP;
    COMMIT;
END;

ALTER TABLE Customers ADD (IsVIP VARCHAR2(5));

DECLARE
    CURSOR customer_cur IS
        SELECT CustomerID, Balance FROM Customers;
    v_customer_id Customers.CustomerID%TYPE;
    v_balance     Customers.Balance%TYPE;
BEGIN
    FOR customer_rec IN customer_cur LOOP
        v_customer_id := customer_rec.CustomerID;
        v_balance := customer_rec.Balance;
        
        IF v_balance > 10000 THEN
            UPDATE Customers
            SET IsVIP = 'TRUE'
            WHERE CustomerID = v_customer_id;
        ELSE
            UPDATE Customers
            SET IsVIP = 'FALSE'
            WHERE CustomerID = v_customer_id;
        END IF;
    END LOOP;
    COMMIT;
END;

DECLARE
    CURSOR loan_cur IS
        SELECT l.LoanID, l.CustomerID, c.Name, l.EndDate
        FROM Loans l
        JOIN Customers c ON l.CustomerID = c.CustomerID
        WHERE l.EndDate BETWEEN SYSDATE AND SYSDATE + 30;
    v_loan_id      Loans.LoanID%TYPE;
    v_customer_id  Loans.CustomerID%TYPE;
    v_customer_name Customers.Name%TYPE;
    v_end_date     Loans.EndDate%TYPE;
BEGIN
    FOR loan_rec IN loan_cur LOOP
        v_loan_id := loan_rec.LoanID;
        v_customer_id := loan_rec.CustomerID;
        v_customer_name := loan_rec.Name;
        v_end_date := loan_rec.EndDate;

        DBMS_OUTPUT.PUT_LINE('Reminder: Dear ' || v_customer_name || 
                             ', your loan (ID: ' || v_loan_id || ') is due on ' || 
                             TO_CHAR(v_end_date, 'YYYY-MM-DD') || '.');
    END LOOP;
END;

