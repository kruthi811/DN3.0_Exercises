CREATE OR REPLACE FUNCTION CalculateAge (
    p_dob IN DATE
) 
RETURN NUMBER 
IS
    v_age NUMBER;
BEGIN
    v_age := FLOOR(MONTHS_BETWEEN(SYSDATE, p_dob) / 12);
    RETURN v_age;
END CalculateAge;



CREATE OR REPLACE FUNCTION CalculateMonthlyInstallment (
    p_loan_amount IN NUMBER,
    p_interest_rate IN NUMBER,
    p_duration_years IN NUMBER
) 
RETURN NUMBER 
IS
    v_monthly_rate NUMBER;
    v_number_of_payments NUMBER;
    v_monthly_installment NUMBER;
BEGIN
    v_monthly_rate := p_interest_rate / 100 / 12;
    v_number_of_payments := p_duration_years * 12;

    IF v_monthly_rate = 0 THEN
        v_monthly_installment := p_loan_amount / v_number_of_payments;
    ELSE
        v_monthly_installment := p_loan_amount * v_monthly_rate / (1 - POWER(1 + v_monthly_rate, -v_number_of_payments));
    END IF;

    RETURN v_monthly_installment;
END CalculateMonthlyInstallment;

CREATE OR REPLACE FUNCTION HasSufficientBalance (
    p_account_id IN Accounts.AccountID%TYPE,
    p_amount IN NUMBER
) 
RETURN BOOLEAN 
IS
    v_balance Accounts.Balance%TYPE;
BEGIN
    -- Get the balance of the account
    SELECT Balance INTO v_balance
    FROM Accounts
    WHERE AccountID = p_account_id;

    IF v_balance >= p_amount THEN
        RETURN TRUE;
    ELSE
        RETURN FALSE;
    END IF;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN FALSE;
    WHEN OTHERS THEN
        RETURN FALSE;
END HasSufficientBalance;

DECLARE
    v_age NUMBER;
    v_monthly_installment NUMBER;
    v_has_sufficient_balance BOOLEAN;
BEGIN
    -- Calculate age
    v_age := CalculateAge(TO_DATE('1985-05-15', 'YYYY-MM-DD'));
    DBMS_OUTPUT.PUT_LINE('Age: ' || v_age);

    -- Calculate monthly installment
    v_monthly_installment := CalculateMonthlyInstallment(5000, 5, 5);
    DBMS_OUTPUT.PUT_LINE('Monthly Installment: ' || v_monthly_installment);

    -- Check sufficient balance
    v_has_sufficient_balance := HasSufficientBalance(1, 500);
    IF v_has_sufficient_balance THEN
        DBMS_OUTPUT.PUT_LINE('Account has sufficient balance.');
    ELSE
        DBMS_OUTPUT.PUT_LINE('Account does not have sufficient balance.');
    END IF;
END;


